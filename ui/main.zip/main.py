from sidebar import sidebar

option = sidebar()

option()